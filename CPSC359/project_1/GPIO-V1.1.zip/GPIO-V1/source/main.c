#include <unistd.h>
#include <stdio.h>
#include "initGPIO.h"

int main()
{
	// get gpio pointer
    unsigned int *gpioPtr = getGPIOPtr();  
	
	printf("pointer address: %p\n", gpioPtr);

    return 0;
}
